Page({
    clickMe(event) {
      console.log(11111111111)
    }
  })